package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entities.Address;
import com.example.demo.exception.AddressException;
import com.example.demo.service.AddressServiceImpl;


@SpringBootTest
class OnlineMobileShoppingApplicationTests {
	
	private AddressServiceImpl addressService =new AddressServiceImpl();

	@Test
	void contextLoads() {
	}
   
	
	
	
	
	
}
