package com.example.demo.exception;

public class CardException extends Exception{
	public CardException(String message) {
		super(message);
	}
}
