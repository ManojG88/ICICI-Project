package com.example.demo.entities;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Address {
   
	@Id
	@Email(message = "Please enter valid Email eg: yourname@ipru.com.")
	private String emailId;
	
	@NotBlank(message = "Name can't be Blank.")
	@NotBlank(message="City can't be blank")
	String streetname;
	String city;
	@NotBlank(message="city can't be blank")
	String  pincode;
	@NotBlank(message="can't be blank")
	String  district;
	@NotBlank(message="State can't be blank")
	String  state;
    String  country;
   
	public Address() 
	{
		super();
	}
	
	/**
	 * @param add_Id
	 * @param streetname 
	 * @param city
	 * @param pincode
	 * @param district
	 * @param state 
	 * @param country 
	 * @param emailid 

	 */
	public Address(String city, String district, String state, String pincode, String country, String streetname, @Pattern(regexp = "^[a-zA-Z0-9_!#$%&’*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$", message = "EmailId Should be Contain: ^[a-zA-Z0-9_!#$%&’*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$ These Chars.") @NotBlank(message = "Name can't be Blank.") @Email(message = "Please enter valid Email eg: yourname@ipru.com.") String emailid) {
		super();
	
		this.emailId=emailid;
		this.streetname=streetname;
		this.city = city;
		this.pincode=pincode;
		this.district = district;
		this.state = state;
		this.country=country;
		
	}
	
	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getStreetname() {
		return streetname;
	}

	public void setStreetname(String streetname) {
		this.streetname = streetname;
	}


	
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getEmailId() {
		return emailId;
	}

	/**
	 * @return the addressid
	 */
	
	
}
