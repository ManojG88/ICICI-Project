package com.example.demo.exception;

public class CustomerException extends Exception {
	public CustomerException(String message) {
		super(message);
	}
}