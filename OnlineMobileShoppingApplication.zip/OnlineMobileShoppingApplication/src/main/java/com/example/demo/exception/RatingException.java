package com.example.demo.exception;

public class RatingException extends Exception {
	public RatingException(String message) {
		super(message);
	}
}

